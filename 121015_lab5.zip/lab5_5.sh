echo "Enter first Filename: "
read file1
echo "Enter second Filename: "
read file2
flag=0
if test -e $file1
then
	echo $file1 exists
else
echo $file1 does not exists		
fi	

if test -e $file2
then
	echo $file2 exists
	cat $file1 >> $file2
else
cat $file1 > $file2
echo $file1 does not exists		
fi	

