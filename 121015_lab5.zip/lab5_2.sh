p=`expr $1 | rev`
if [ $p == $1 ]
then
	echo String $1 is a palindrome
else
	echo String $1 is not a palindrome
fi	
