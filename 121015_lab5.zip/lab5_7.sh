echo "Enter alphabet: "
read alphabet
ls $alphabet*
