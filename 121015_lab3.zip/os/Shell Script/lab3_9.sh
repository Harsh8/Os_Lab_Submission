a=1
while [  $a -eq 1 ]
do
	echo "What is the capital of Gujarat? "
	read ans
	if [ $ans = " Gandhinagar " ] ; 
	then
	{
		a=-1
		echo "Good Job";
	}
	fi
done
