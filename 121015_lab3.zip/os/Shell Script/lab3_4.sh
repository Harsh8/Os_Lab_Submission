echo "x: "
read x
echo "y: "
read y
if [ $x  -gt  $y  ] ; then
	{
		echo "$x is greater";
	}
elif [ $x  -lt  $y  ] ; then
	{
		echo "$y is greater";
	}
else
	{
		echo "both equal";
	}
fi
