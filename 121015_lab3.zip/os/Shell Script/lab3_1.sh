echo "Enter 1st no: "
read a
echo "Enter 2nd no: "
read b
n1=` expr $a + $b `
n2=` expr $a - $b `
n3=` expr $a \* $b `
if [ $a -ge $b ]
then
n4=` expr $a / $b `
n5=` expr $a % $b `
else
n4=` expr $b / $a `
n5=` expr $b % $a `
fi

echo "addition: $n1 subtraction: $n2 multiplication: $n3 quotient: $n4 remainder: $n5"
