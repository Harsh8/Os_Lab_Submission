echo "write command"
read comd
exec $comd
