ch="y"
while [ " $ch " = " y " ]
do
	echo "enter numbers (below 50)"
	rechd x
	if [  $x  -le 50 ]  
	then
	{
		n=` expr $x \* $x `
		echo $n;
	}
	else
	{
		echo "number not below 50";
	}
	fi
	echo "do you want to continue? (y/n)"
	read ch	
done
