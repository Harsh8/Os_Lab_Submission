i=0
b=0
echo "Enter the length of the list: "
read n
echo ${num[n]}
echo "Enter the list of numbers: "
for((i=0;i<n;i++))
do
	read num[$i]
done
echo "Enter the element to be searched: "
read a
i=1
while [ $b -eq 0 -a $i -le $n ]
do
if [  $a -eq num[$i] ] 
then
	echo "element in list at index number $i"
	b=1
fi
i = $i + 1
done

if [ $b -eq 0 ]
echo "element not in list"
fi
