
read x
read op
read y

case $op in
	+) echo "`expr $x + $y`" ;;

	-) echo "`expr $x - $y`" ;;
	
	\*) echo "`expr $x \* $y`";;

	/) echo "`expr $x / $y`" ;;

	%) echo "`expr $x % $y`" ;;	

	*) echo Invalid Choice
esac

