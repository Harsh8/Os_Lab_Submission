num1=1
echo $num1

num2=1
echo $num2

for((i=0;i<20;i++))
do
	num3=` expr $num1 + $num2 `
	echo $num3

	num1=$num2
	num2=$num3
done	
